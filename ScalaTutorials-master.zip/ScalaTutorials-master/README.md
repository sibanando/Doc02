# Scala Tutorials
Example Code & Notebooks for Scala Tutorials @ Learning Journal  
Visit https://learningjournal.guru/ for Video Tutorials

